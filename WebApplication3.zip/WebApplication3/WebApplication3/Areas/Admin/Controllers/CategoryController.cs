﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication3.DAL;
using WebApplication3.Extentions;
using WebApplication3.Models;

namespace WebApplication3.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class CategoryController : Controller
    {
        private readonly AppDbContext _db;
        private readonly IWebHostEnvironment _env;
        public CategoryController(AppDbContext db, IWebHostEnvironment env)
        {
            _db = db;
            _env = env;
        }
        public IActionResult Index()
        {
            return View(_db.Categories.Where(c=>c.IsDeleted==false));
        }

        public IActionResult Create()
        {
            ViewBag.MainCtg = _db.Categories.Where(c => c.IsMain == true && c.IsDeleted == false).ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Category category,int? MainCtgId)
        {
            ViewBag.MainCtg = _db.Categories.Where(c => c.IsMain == true && c.IsDeleted == false).ToList();
            if (!ModelState.IsValid) return View();
            if (category.IsMain)
            {
                
                bool IsExist = _db.Categories.Where(c => c.IsMain == true && c.IsDeleted == false)
                    .Any(c => c.Name.ToLower() == category.Name.ToLower());
                if (IsExist)
                {
                    ModelState.AddModelError("Name", "This main category already exist");
                    return View();
                }
                if (category.Photo == null)
                {
                    ModelState.AddModelError("", "If Main Category Created Please Select Photo");
                    return View();
                }
                if (!category.Photo.IsImage())
                {
                    ModelState.AddModelError("", "If Main Category Created Please Select Photo");
                    return View();
                }
                if (category.Photo.MaxLength(300))
                {
                    ModelState.AddModelError("", "If Main Category Created Please Select Photo,max Length=300 kb");
                    return View();
                }

                string folder = Path.Combine("assets", "images");
                string fileName =await category.Photo.SaveImg(_env.WebRootPath, folder);
                category.Image = fileName;
                category.IsDeleted = false;
            }
            else
            {
                Category dbCategory =_db.Categories.Include(c=>c.Children).FirstOrDefault(c=>c.Id== MainCtgId);
                if (dbCategory == null) return NotFound();
                foreach (Category item in dbCategory.Children)
                {
                    if (item.Name.ToLower() == category.Name.ToLower()&&item.IsDeleted==false)
                    {
                        ModelState.AddModelError("Name", $"{dbCategory.Name}-kateqoriyasinin {item.Name} adli alt kateqoriyasi var");
                        return View();
                    }
                }
                category.Parent = dbCategory;
            }
            await _db.Categories.AddAsync(category);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();
            Category category =_db.Categories.Include(c=>c.Children).Include(c=>c.Parent).FirstOrDefault(c=>c.Id==id);
            if (category == null) return NotFound();
            return View(category);
        }

        [HttpPost]
        [ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeletePost(int? id)
        {
            if (id == null) return NotFound();
            Category category = _db.Categories.Include(c=>c.Children).FirstOrDefault(c => c.Id == id);
            if (category == null) return NotFound();

            //Children varsa error verecek
            //_db.Categories.Remove(category);

            //Children ile birlikde hamisini silmek
            //_db.Categories.Remove(category);
            //foreach (Category item in category.Children)
            //{
            //    _db.Categories.Remove(item);
            //}

            category.IsDeleted = true;
            foreach (Category item in category.Children)
            {
                item.IsDeleted = true;
            }
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}